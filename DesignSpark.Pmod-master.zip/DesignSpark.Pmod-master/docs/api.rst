API
---

:mod:`DesignSpark.Pmod.AD1`
"""""""""""""""""""""""""""

.. automodule:: DesignSpark.Pmod.AD1
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`DesignSpark.Pmod.Error`
"""""""""""""""""""""""""""""

.. automodule:: DesignSpark.Pmod.Error
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`DesignSpark.Pmod.HAT`
"""""""""""""""""""""""""""

.. automodule:: DesignSpark.Pmod.HAT
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`DesignSpark.Pmod.HB3`
"""""""""""""""""""""""""""

.. automodule:: DesignSpark.Pmod.HB3
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`DesignSpark.Pmod.ISNS20`
""""""""""""""""""""""""""""""

.. automodule:: DesignSpark.Pmod.ISNS20
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`DesignSpark.Pmod.MIC3`
""""""""""""""""""""""""""""

.. automodule:: DesignSpark.Pmod.MIC3
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`DesignSpark.Pmod.OLEDrgb`
"""""""""""""""""""""""""""""""

.. automodule:: DesignSpark.Pmod.OLEDrgb
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:

:mod:`DesignSpark.Pmod.TC1`
"""""""""""""""""""""""""""

.. automodule:: DesignSpark.Pmod.TC1
    :members:
    :undoc-members:
    :show-inheritance:

