.. include:: ../README.rst

Table of Contents
-----------------

.. toctree::
   :maxdepth: 1
   :numbered:

   installation
   pmod-information
   basic-examples
   advanced-examples
   api

.. include:: ../CHANGES.rst
.. include:: ../LICENSE.rst
