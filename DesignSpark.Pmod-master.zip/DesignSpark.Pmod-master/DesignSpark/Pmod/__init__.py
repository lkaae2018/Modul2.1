# -*- coding: utf-8 -*-
# Copyright (c) 2017 RS Components Ltd
# SPDX-License-Identifier: MIT License

"""
A Python library for use with a Raspberry Pi, Pmod HAT and selected Pmods
"""

__version__ = '0.2.0'
