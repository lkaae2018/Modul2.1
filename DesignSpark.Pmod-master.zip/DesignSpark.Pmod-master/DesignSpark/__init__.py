# -*- coding: utf-8 -*-
# Copyright (c) 2017 RS Components Ltd
# SPDX-License-Identifier: MIT License

from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)
